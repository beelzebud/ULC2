#include <QApplication>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("libretro Updater");
    app.setOrganizationName("ulc");

    MainWindow w;
    w.show();

    return app.exec();
}
